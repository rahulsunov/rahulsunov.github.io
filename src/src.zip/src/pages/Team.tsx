import { useScrollReveal } from '@/hooks/useScrollReveal';

const Team = () => {
  const titleRef = useScrollReveal();
  const contentRef = useScrollReveal();

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div ref={titleRef} className="scroll-reveal text-center mb-16">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-foreground mb-6">
            Our <span className="text-primary">Team</span>
          </h1>
          <p className="font-body text-lg text-foreground-secondary max-w-2xl mx-auto">
            Meet the passionate individuals working tirelessly behind the scenes 
            to bring you an unforgettable TEDx experience.
          </p>
        </div>

        <div ref={contentRef} className="scroll-reveal">
          <div className="text-center py-20">
            <div className="card-premium p-12 rounded-xl max-w-lg mx-auto">
              <h3 className="font-heading text-2xl font-semibold text-foreground mb-4">
                Team Reveal Coming Soon
              </h3>
              <p className="font-body text-foreground-muted">
                We're putting together an incredible team of organizers, 
                curators, and volunteers. Stay tuned to meet the faces behind TEDxMDIGurgaon 4.0!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Team;