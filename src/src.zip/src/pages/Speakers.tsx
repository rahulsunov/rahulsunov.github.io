import { useScrollReveal } from '@/hooks/useScrollReveal';

const Speakers = () => {
  const titleRef = useScrollReveal();
  const contentRef = useScrollReveal();

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div ref={titleRef} className="scroll-reveal text-center mb-16">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-foreground mb-6">
            Our <span className="text-primary">Speakers</span>
          </h1>
          <p className="font-body text-lg text-foreground-secondary max-w-2xl mx-auto">
            Meet the visionaries, innovators, and thought leaders who will share their 
            groundbreaking ideas at TEDxMDIGurgaon 4.0.
          </p>
        </div>

        <div ref={contentRef} className="scroll-reveal">
          <div className="text-center py-20">
            <div className="card-premium p-12 rounded-xl max-w-lg mx-auto">
              <h3 className="font-heading text-2xl font-semibold text-foreground mb-4">
                Coming Soon
              </h3>
              <p className="font-body text-foreground-muted">
                We're curating an exceptional lineup of speakers. 
                Stay tuned for announcements!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Speakers;