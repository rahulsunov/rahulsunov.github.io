import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const Index = () => {
  const aboutRef = useScrollReveal();
  const statsRef = useScrollReveal();

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      
      {/* About Section */}
      <section className="py-20 bg-background-secondary">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div ref={aboutRef} className="scroll-reveal text-center">
            <h2 className="font-heading text-3xl md:text-5xl font-bold text-foreground mb-8">
              About <span className="text-primary">TEDx</span>
            </h2>
            <p className="font-body text-lg text-foreground-secondary max-w-3xl mx-auto leading-relaxed">
              TEDx was created in the spirit of TED's mission, "ideas worth spreading." 
              The program is designed to give communities, organizations and individuals 
              the opportunity to stimulate dialogue through TED-like experiences at the local level.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div ref={statsRef} className="scroll-reveal grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { number: '3', label: 'Previous Events', suffix: '+' },
              { number: '50', label: 'Amazing Speakers', suffix: '+' },
              { number: '5000', label: 'Inspired Minds', suffix: '+' }
            ].map((stat, index) => (
              <div key={index} className="card-premium p-8 rounded-xl text-center">
                <div className="font-heading text-4xl md:text-6xl font-bold text-primary mb-2">
                  {stat.number}<span className="text-foreground-secondary">{stat.suffix}</span>
                </div>
                <p className="font-body text-foreground-muted uppercase tracking-wider text-sm">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
