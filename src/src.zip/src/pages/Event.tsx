import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Calendar, MapPin, Clock, Users } from 'lucide-react';

const Event = () => {
  const titleRef = useScrollReveal();
  const featuresRef = useScrollReveal();
  const detailsRef = useScrollReveal();

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div ref={titleRef} className="scroll-reveal text-center mb-16">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-foreground mb-6">
            Event <span className="text-primary">4.0</span>
          </h1>
          <p className="font-body text-lg text-foreground-secondary max-w-2xl mx-auto">
            The fourth edition of TEDxMDIGurgaon promises to be our most ambitious yet, 
            featuring cutting-edge ideas and transformative conversations.
          </p>
        </div>

        <div ref={featuresRef} className="scroll-reveal grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {[
            { icon: Calendar, title: 'Date', value: 'Coming Soon', description: 'Save the date' },
            { icon: MapPin, title: 'Venue', value: 'MDI Gurgaon', description: 'Premium location' },
            { icon: Clock, title: 'Duration', value: 'Full Day', description: 'Immersive experience' },
            { icon: Users, title: 'Speakers', value: '10+', description: 'Industry leaders' }
          ].map((item, index) => (
            <div key={index} className="card-premium p-6 rounded-xl text-center group hover:scale-105 transition-transform duration-300">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-full mb-4 group-hover:bg-primary/20 transition-colors">
                <item.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-semibold text-foreground mb-2">{item.title}</h3>
              <p className="font-body text-xl font-bold text-primary mb-1">{item.value}</p>
              <p className="font-body text-sm text-foreground-muted">{item.description}</p>
            </div>
          ))}
        </div>

        <div ref={detailsRef} className="scroll-reveal">
          <div className="card-premium p-8 md:p-12 rounded-xl">
            <h2 className="font-heading text-3xl font-bold text-foreground mb-8 text-center">
              What to Expect
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-heading text-xl font-semibold text-foreground mb-4">
                  Revolutionary Ideas
                </h3>
                <p className="font-body text-foreground-secondary mb-6">
                  Experience groundbreaking concepts that challenge conventional thinking 
                  and inspire innovative solutions to global challenges.
                </p>
                
                <h3 className="font-heading text-xl font-semibold text-foreground mb-4">
                  Networking Excellence
                </h3>
                <p className="font-body text-foreground-secondary">
                  Connect with like-minded individuals, industry leaders, and change-makers 
                  in an environment designed for meaningful conversations.
                </p>
              </div>
              <div>
                <h3 className="font-heading text-xl font-semibold text-foreground mb-4">
                  Interactive Sessions
                </h3>
                <p className="font-body text-foreground-secondary mb-6">
                  Participate in thought-provoking discussions, workshops, and interactive 
                  experiences that go beyond traditional presentations.
                </p>
                
                <h3 className="font-heading text-xl font-semibold text-foreground mb-4">
                  Cultural Impact
                </h3>
                <p className="font-body text-foreground-secondary">
                  Be part of a movement that creates lasting impact, fostering innovation 
                  and positive change in our community and beyond.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Event;