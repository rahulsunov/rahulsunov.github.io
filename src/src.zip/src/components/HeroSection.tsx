import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import ParticleBackground from './ParticleBackground';
import { ArrowRight, Play } from 'lucide-react';

const HeroSection = () => {
  const [displayText, setDisplayText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showCursor, setShowCursor] = useState(true);
  const fullText = 'TEDxMDIGurgaon';

  useEffect(() => {
    if (currentIndex < fullText.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + fullText[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, 150);
      return () => clearTimeout(timeout);
    } else {
      // Blink cursor after typing is complete
      const cursorInterval = setInterval(() => {
        setShowCursor(prev => !prev);
      }, 530);
      return () => clearInterval(cursorInterval);
    }
  }, [currentIndex, fullText]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background-secondary to-background-tertiary" />
      
      {/* Particle Background */}
      <ParticleBackground />

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        {/* Main Title with Typewriter Effect */}
        <div className="mb-8">
          <h1 className="font-heading text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight">
            <span className="text-foreground">{displayText}</span>
            <span 
              className={`text-primary transition-opacity duration-100 ${
                showCursor ? 'opacity-100' : 'opacity-0'
              }`}
            >
              |
            </span>
          </h1>
          
          {/* Animated underline */}
          <div className="mt-6 flex justify-center">
            <div 
              className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent transition-all duration-1000 ease-premium"
              style={{
                width: currentIndex >= fullText.length ? '200px' : '0px'
              }}
            />
          </div>
        </div>

        {/* Subtitle */}
        <div className="mb-12 opacity-0 animate-slide-up" style={{ animationDelay: '2s' }}>
          <p className="font-body text-lg md:text-xl lg:text-2xl text-foreground-secondary font-light leading-relaxed">
            Ideas Worth Spreading
          </p>
          <p className="font-body text-base md:text-lg text-foreground-muted mt-4 max-w-2xl mx-auto">
            Join us for an extraordinary journey of innovation, inspiration, and intellectual discourse 
            at Management Development Institute, Gurgaon.
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center opacity-0 animate-slide-up" style={{ animationDelay: '2.5s' }}>
          <Button 
            size="lg" 
            className="btn-neumorphic group px-8 py-4 text-lg font-medium bg-primary hover:bg-primary-glow text-primary-foreground"
          >
            <span>Get Your Tickets</span>
            <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
          </Button>
          
          <Button 
            variant="outline" 
            size="lg" 
            className="glass group px-8 py-4 text-lg font-medium border-border hover:border-primary"
          >
            <Play className="mr-2 h-5 w-5" />
            <span>Watch Highlights</span>
          </Button>
        </div>

        {/* Event Info */}
        <div className="mt-16 opacity-0 animate-fade-in" style={{ animationDelay: '3s' }}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="text-center">
              <p className="font-heading text-sm uppercase tracking-wider text-foreground-muted mb-2">Date</p>
              <p className="font-body text-lg font-medium text-foreground">Coming Soon</p>
            </div>
            <div className="text-center">
              <p className="font-heading text-sm uppercase tracking-wider text-foreground-muted mb-2">Venue</p>
              <p className="font-body text-lg font-medium text-foreground">MDI Gurgaon</p>
            </div>
            <div className="text-center">
              <p className="font-heading text-sm uppercase tracking-wider text-foreground-muted mb-2">Edition</p>
              <p className="font-body text-lg font-medium text-foreground text-primary">4.0</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 opacity-0 animate-fade-in" style={{ animationDelay: '3.5s' }}>
        <div className="w-6 h-10 border-2 border-foreground-muted rounded-full p-1">
          <div className="w-1 h-3 bg-primary rounded-full mx-auto animate-bounce" />
        </div>
        <p className="font-body text-xs text-foreground-muted mt-2 tracking-wider">SCROLL</p>
      </div>
    </section>
  );
};

export default HeroSection;