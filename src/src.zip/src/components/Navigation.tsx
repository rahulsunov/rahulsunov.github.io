import { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Speakers', path: '/speakers' },
    { name: 'Event 4.0', path: '/event' },
    { name: 'Team', path: '/team' }
  ];

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  return (
    <>
      <nav
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-premium',
          isScrolled
            ? 'bg-background/80 backdrop-blur-glass border-b border-border'
            : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <NavLink 
              to="/" 
              className="font-heading text-xl lg:text-2xl font-bold text-foreground hover:text-primary transition-colors duration-300"
            >
              TEDx<span className="text-primary">MDIGurgaon</span>
            </NavLink>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  className={({ isActive }) =>
                    cn(
                      'font-body text-sm font-medium tracking-wide transition-all duration-300 relative',
                      'before:absolute before:bottom-0 before:left-0 before:w-0 before:h-0.5 before:bg-primary before:transition-all before:duration-300',
                      'hover:text-primary hover:before:w-full',
                      isActive 
                        ? 'text-primary before:w-full' 
                        : 'text-foreground-secondary'
                    )
                  }
                >
                  {item.name}
                </NavLink>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden w-8 h-8 flex items-center justify-center text-foreground hover:text-primary transition-colors duration-300"
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={cn(
          'fixed inset-0 z-40 transition-opacity duration-500 md:hidden',
          isMobileMenuOpen 
            ? 'opacity-100 pointer-events-auto' 
            : 'opacity-0 pointer-events-none'
        )}
        onClick={closeMobileMenu}
      >
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          'fixed top-0 right-0 bottom-0 z-50 w-80 max-w-[80vw] transition-transform duration-500 ease-premium md:hidden',
          'bg-background-secondary/95 backdrop-blur-glass border-l border-border',
          isMobileMenuOpen 
            ? 'transform translate-x-0' 
            : 'transform translate-x-full'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Mobile Menu Header */}
          <div className="flex items-center justify-between p-6 border-b border-border">
            <span className="font-heading text-lg font-bold text-foreground">
              TEDx<span className="text-primary">MDIGurgaon</span>
            </span>
            <button
              onClick={closeMobileMenu}
              className="w-8 h-8 flex items-center justify-center text-foreground-secondary hover:text-primary transition-colors duration-300"
              aria-label="Close menu"
            >
              <X size={20} />
            </button>
          </div>

          {/* Mobile Menu Items */}
          <div className="flex-1 px-6 py-8">
            <div className="space-y-6">
              {navItems.map((item, index) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  onClick={closeMobileMenu}
                  className={({ isActive }) =>
                    cn(
                      'block font-body text-lg font-medium transition-all duration-300',
                      'hover:text-primary hover:translate-x-2',
                      isActive 
                        ? 'text-primary' 
                        : 'text-foreground-secondary'
                    )
                  }
                  style={{
                    animationDelay: `${index * 100}ms`
                  }}
                >
                  {item.name}
                </NavLink>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navigation;